<?php
/**
 * Copyright © LTIMindtree All rights reserved.
 * See COPYING.txt for license details.
 */

namespace LTIM\ProductImageCustomizer\Controller\Index;

use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\Request\Http as Request;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem\Io\File;
use Magento\Framework\Filesystem\Driver\File as DriverFile;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Quote\Model\ResourceModel\Quote\Item\CollectionFactory;
use Magento\Quote\Api\CartRepositoryInterface;
use LTIM\ProductImageCustomizer\ViewModel\Data;
use Magento\Framework\UrlInterface;
use Magento\Framework\Controller\Result\RedirectFactory;

/**
 * Index Controller
 */
class Index implements HttpPostActionInterface
{

    /**
     * @var Request
     */
    protected Request $_request;

    /**
     * @var ResultFactory
     */
    protected ResultFactory $_resultFactory;

    /**
     * @var FileSystem
     */
    protected Filesystem $_fileSystem;

    /**
     * @var File
     */
    protected File $_directory;

    /**
     * @var DriverFile
     */
    protected DriverFile $_driverFile;

    /**
     * @var CheckoutSession
     */
    protected CheckoutSession $_checkoutSession;

    /**
     * @var CollectionFactory
     */
    protected CollectionFactory $_itemFactory;

    /**
     * @var CartRepositoryInterface
     */
    protected CartRepositoryInterface $_quoteRepository;

    /**
     * @var Data
     */
    protected Data $viewModel;

    /**
     * @var UrlInterface
     */
    protected UrlInterface $_urlInterface;

    /**
     * @var RedirectFactory
     */
    protected RedirectFactory $_resultRedirectFactory;

    /**
     * @param Request $request
     * @param ResultFactory $resultFactory
     * @param Filesystem $fileSystem
     * @param File $directory
     * @param DriverFile $driverFile
     * @param CheckoutSession $checkoutSession
     * @param CollectionFactory $itemFactory
     * @param CartRepositoryInterface $quoteRepository
     * @param Data $viewModel
     * @param UrlInterface $urlInterface
     * @param RedirectFactory $resultRedirectFactory
     */
    public function __construct(
        Request                 $request,
        ResultFactory           $resultFactory,
        FileSystem              $fileSystem,
        File                    $directory,
        DriverFile              $driverFile,
        CheckoutSession         $checkoutSession,
        CollectionFactory       $itemFactory,
        CartRepositoryInterface $quoteRepository,
        Data                    $viewModel,
        UrlInterface            $urlInterface,
        RedirectFactory         $resultRedirectFactory
    ) {
        $this->_request = $request;
        $this->_resultFactory = $resultFactory;
        $this->_fileSystem = $fileSystem;
        $this->_directory = $directory;
        $this->_driverFile = $driverFile;
        $this->_checkoutSession = $checkoutSession;
        $this->_itemFactory = $itemFactory;
        $this->_quoteRepository = $quoteRepository;
        $this->viewModel = $viewModel;
        $this->_urlInterface = $urlInterface;
        $this->_resultRedirectFactory = $resultRedirectFactory;
    }

    /**
     * Returns the ajax request result and saves the image in directory
     *
     * @return Redirect
     *
     * @throws NoSuchEntityException
     * @throws FileSystemException
     * @throws LocalizedException
     */
    public function execute()
    {
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/hello.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $logger->info("@@@@@@");

        $productId = $this->_request->getParam("productId");
        $moduleStatus = $this->viewModel->getProductCustomizerStatus($productId);
        if (!$moduleStatus):
            $noRouteUrl = $this->_urlInterface->getUrl('noroute');
            return $this->_resultRedirectFactory->create()->setUrl($noRouteUrl);
        endif;
        $encodeImg = $this->_request->getParam("dataURL");
        $logger->info("encodeImg".$encodeImg);
        $imageCustomizerName = $this->_request->getParam("name");
        $imageCustomizerDescription = $this->_request->getParam("description");

        $encodedImage = str_replace("data:image/png;base64,", "", $encodeImg);
        $logger->info("encodedImage>".$encodedImage);

        $image = base64_decode($encodedImage);
        $logger->info("image>".$image);

        $mediaPath = $this->_fileSystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
        $logger->info("mediaPath>".$mediaPath);

        $path = $mediaPath . 'product_customizer';
        if (!$this->_driverFile->isExists($path)):
            $this->_directory->mkdir($path, 0775);
        endif;
        $quoteId = $this->_checkoutSession->getQuote()->getId();
        $logger->info("product_id test>".$productId);
        $logger->info("quoteItemId test>".$quoteId);
        $quoteItemCollection = $this->_itemFactory->create()
            ->addFieldToFilter("product_id", $productId)
            ->addFieldToFilter("quote_id", $quoteId);
        $quoteItemId = $quoteItemCollection->getLastItem()->getItemId();
        $logger->info("quoteItemId>".$quoteItemId);

        $imagePath = $path . '/' . $quoteId . '_' . $quoteItemId . '.png';
        $logger->info("imagePath>".$imagePath);

        $this->_directory->write($imagePath, $image);
        $quote = $this->_quoteRepository->getActive($quoteId);
        $quoteItem = $quote->getItemById($quoteItemId);
        if ($quoteItem):
            $logger->info("INSIDEIF".__LINE__);

            $quoteItem->setImageCustomizerPath($quoteId . '_' . $quoteItemId . '.png');
            $quoteItem->setImageCustomizerName($imageCustomizerName);
            $quoteItem->setImageCustomizerDescription($imageCustomizerDescription);
            $quoteItem->save();
        endif;
        $resultJson = $this->_resultFactory->create(ResultFactory::TYPE_JSON);
        return $resultJson->setData(["status" => __("success")]);
    }
}
