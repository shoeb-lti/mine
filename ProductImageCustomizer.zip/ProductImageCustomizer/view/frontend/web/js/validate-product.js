/**
 * Copyright © LTIMindtree All rights reserved.
 * See COPYING.txt for license details.
*/
define([
    'jquery',
    'mage/mage',
    'Magento_Catalog/product/view/validation',
    'catalogAddToCart',
    'mage/url'
], function ($, mage, validation, addToCart, urlBuilder) {
    'use strict';

    $.widget('mage.productValidate', {
        options: {
            bindSubmit: false,
            radioCheckboxClosest: '.nested',
            addToCartButtonSelector: '.action.tocart'
        },

        /**
         * Uses Magento validation widget for the form object.
         * @private
         */
        _create: function () {
            var bindSubmit = this.options.bindSubmit;

            this.element.validation({
                radioCheckboxClosest: this.options.radioCheckboxClosest,

                /**
                 * Uses catalogAddToCart widget as submit handler.
                 * @param {Object} form
                 * @returns {Boolean}
                 */
                submitHandler: function (form) {
                    var jqForm = $(form).catalogAddToCart({
                        bindSubmit: bindSubmit
                    });

                    jqForm.catalogAddToCart('submitForm', jqForm);

                    //Upload image to product image customizer start
                    var label = $('.customize-label');
                    var description = $('.customize-description');
                    if(label.text() && description.text()){
                        var container =$('.fotorama__img');
                        var productId = $("input[name=product]").val();
                        var imgPrev = document.querySelector('.fotorama__img');
                        var canvas = document.createElement("canvas");
                        var context = canvas.getContext("2d");
                        canvas.setAttribute('width', container.width());
                        canvas.setAttribute('height', container.height());
                        document.body.appendChild(canvas);
                        var imageObj1 = new Image();
                        var imageObj2 = new Image();
                        imageObj1.src = $(".fotorama__img").attr('src');
                        imageObj1.onload = function() {
                            context.drawImage(imgPrev, 0, 0);
                            imageObj2.src = $('#customizer-upload-img').attr('src');
                            /* Old Logic commented & added new condition here
                                if(imageObj2.src)
                            */
                            if(imageObj2.src.indexOf('data:image') != -1) {
                            /* If image file uploaded */
                                imageObj2.onload = function() {
                                    context.drawImage(imageObj2, 430, 370, 100, 100);
                                    context.font = "bold 20px serif";
                                    context.textBaseline = 'middle'; 
                                    context.textAlign = 'center'; 
                                    context.fillText(label.text(), container.width()/2, container.height()/2.7);
                                    context.fillText(description.text(), container.width()/2, container.height()/2);
                                    context.strokeRect(0, 0, canvas.width, canvas.height);
                                    var dataURL = canvas.toDataURL();
                                    productCustomizerAjax(dataURL, productId, label.text(), description.text());
                                }
                            } else {
                                /* If no image file uploaded */
                                context.font = "bold 20px serif";
                                context.textBaseline = 'middle'; 
                                context.textAlign = 'center'; 
                                context.fillText(label.text(), container.width()/2, container.height()/2.7);
                                context.fillText(description.text(), container.width()/2, container.height()/2);
                                context.strokeRect(0, 0, canvas.width, canvas.height);
                                var dataURL = canvas.toDataURL();
                                productCustomizerAjax(dataURL, productId, label.text(), description.text());
                            }
                        };
                        function productCustomizerAjax(dataURL, productId, label, description) {
                            $.ajax({
                                url: urlBuilder.build("productimagecustomizer/index/index"),
                                type: 'POST', 
                                showLoader: true,
                                data: {dataURL: dataURL, productId: productId, name: label, description: description},
                                success: function (response) {
                                    console.log(response);
                                },
                                error: function () {
                                    
                                }
                            });
                        }
                    }
                            //Upload image to product image customizer end
                            return false;
                }
            });
            $("#image-label").attr("disabled", false);
            $("#image-description").attr("disabled", false);
            $("#image-upload").attr("disabled", false);
            $(this.options.addToCartButtonSelector).attr('disabled', false);
        }
    });

    return $.mage.productValidate;
});
