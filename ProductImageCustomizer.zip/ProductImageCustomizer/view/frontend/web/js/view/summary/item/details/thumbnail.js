/**
 * Copyright © LTIMindtree All rights reserved.
 * See COPYING.txt for license details.
 */

 define(['uiComponent'], function (Component) {
    'use strict';

    var imageData = window.checkoutConfig.imageData;
    var mediaPath = window.checkoutConfig.getMediaPath;
    var quoteItemData = window.checkoutConfig.quoteItemData;

    return Component.extend({
        defaults: {
            template: 'Magento_Checkout/summary/item/details/thumbnail'
        },
        displayArea: 'before_details',
        imageData: imageData,
        mediaPath: mediaPath,
        quoteItemData: quoteItemData,

        /**
         * @param {Object} item
         * @return {Array}
         */
        getImageItem: function (item) {
            if (this.imageData[item['item_id']]) {
                return this.imageData[item['item_id']];
            }

            return [];
        },

        /**
         * @param {Object} item
         * @return {null}
         */
        getSrc: function (item) {
            var item = this.getItem(item['item_id']);
            var customizeImg = item.image_customizer_path;
            if (customizeImg) {
                console.log(this.mediaPath);
                return this.mediaPath + '/' + customizeImg;
            } else {
                if (this.imageData[item['item_id']]) {
                    return this.imageData[item['item_id']].src;
                }
                return null;
            }
        },

        getItem: function (item_id) {
            var itemElement = null;
            _.each(quoteItemData, function (element, index) {
                if (element.item_id == item_id) {
                    itemElement = element;
                }
            });
            return itemElement;
        },

        /**
         * @param {Object} item
         * @return {null}
         */
        getWidth: function (item) {
            if (this.imageData[item['item_id']]) {
                return this.imageData[item['item_id']].width;
            }

            return null;
        },

        /**
         * @param {Object} item
         * @return {null}
         */
        getHeight: function (item) {
            if (this.imageData[item['item_id']]) {
                return this.imageData[item['item_id']].height;
            }

            return null;
        },

        /**
         * @param {Object} item
         * @return {null}
         */
        getAlt: function (item) {
            if (this.imageData[item['item_id']]) {
                return this.imageData[item['item_id']].alt;
            }

            return null;
        }
    });
});
