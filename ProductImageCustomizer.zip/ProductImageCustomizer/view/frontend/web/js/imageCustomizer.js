/**
 * Copyright © LTIMindtree All rights reserved.
 * See COPYING.txt for license details.
 */
 define([
    "jquery",
    "Magento_Ui/js/modal/modal",
    'mage/url',
    'loader'
],
     function ($, modal, urlBuilder, loader) {
         "use strict";

         return function imageCustomizer() {
            $("#image-label").on("keyup change", function(e) {
                $('.customize-label').text($("#image-label").val());
                
            });
            $("#image-description").on("keyup change", function(e) {
                $('.customize-description').text($("#image-description").val());
            });
            $("#image-upload").change(function () {
                if (this.files && this.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $('#customizer-upload-img').attr('src', e.target.result);
                        $('.center-image').css('display', 'block');
                        $('#customizer-upload-img-zoom').attr('src', e.target.result);
                    };
                    reader.readAsDataURL(this.files[0]);
                }
            });
         }
    });
