/**
 * Copyright © LTIMindtree All rights reserved.
 * See COPYING.txt for license details.
 */
 var config = {
    map: {
        '*': {
            imageCustomizer: 'LTIM_ProductImageCustomizer/js/imageCustomizer',
            "mage/gallery/gallery.html": "LTIM_ProductImageCustomizer/template/gallery/gallery.html",
            "Magento_Checkout/template/summary/item/details.html": "LTIM_ProductImageCustomizer/template/summary/item/details.html",
            "Magento_Catalog/js/validate-product": "LTIM_ProductImageCustomizer/js/validate-product",
            "Magento_Checkout/js/view/summary/item/details": "LTIM_ProductImageCustomizer/js/view/summary/item/details",
            "Magento_Checkout/js/view/summary/item/details/thumbnail": "LTIM_ProductImageCustomizer/js/view/summary/item/details/thumbnail",
            "Magento_Checkout/js/view/summary/item/details/subtotal" : "LTIM_ProductImageCustomizer/js/view/summary/item/details/subtotal",
            "Magento_Checkout/js/view/summary/item/details/message" : "LTIM_ProductImageCustomizer/js/view/summary/item/details/message"
        }
    }
}
