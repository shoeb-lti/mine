<?php
/**
 * Copyright © LTIMindtree All rights reserved.
 * See COPYING.txt for license details.
 */

namespace LTIM\ProductImageCustomizer\Plugin\Model\Quote;

use Closure;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Model\Quote\Item\AbstractItem;
use Magento\Quote\Model\Quote\Item\ToOrderItem;
use Magento\Sales\Api\Data\OrderItemInterface;
use LTIM\ProductImageCustomizer\ViewModel\Data;

/**
 * Customizer order item plugin
 */
class CustomizerOrderItem
{
    /**
     * @var Data
     */
    protected Data $viewModel;

    /**
     * @param Data $viewModel
     */
    public function __construct(
        Data $viewModel
    ) {
        $this->viewModel = $viewModel;
    }

    /**
     * Around Convert Plugin
     *
     * @param ToOrderItem $subject
     * @param Closure $proceed
     * @param AbstractItem $item
     * @param array $additional
     * @return OrderItemInterface
     * @throws NoSuchEntityException
     */
    public function aroundConvert(
        ToOrderItem $subject,
        Closure $proceed,
        AbstractItem $item,
        array $additional = []
    ): OrderItemInterface {
        $orderItem = $proceed($item, $additional);
        if ($this->viewModel->getProductCustomizerStatus((int) $item->getData("product_id"))):
            $orderItem->setImageCustomizerPath($item->getData("image_customizer_path"));
            $orderItem->setImageCustomizerName($item->getData("image_customizer_name"));
            $orderItem->setImageCustomizerDescription($item->getData("image_customizer_description"));
        endif;
        return $orderItem;
    }
}
