<?php
/**
 * Copyright © LTIMindtree All rights reserved.
 * See COPYING.txt for license details.
 */

namespace LTIM\ProductImageCustomizer\Plugin\Quote;

use Closure;
use Magento\Catalog\Model\Product;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Model\Quote\Item as QuoteItem;
use LTIM\ProductImageCustomizer\ViewModel\Data;

/**
 * Quote Item add Plugin
 */
class Item
{
    /**
     * @var Data
     */
    protected Data $viewModel;

    /**
     * @param Data $viewModel
     */
    public function __construct(
        Data $viewModel
    ) {
        $this->viewModel = $viewModel;
    }

    /**
     * Around Represent Product Plugin
     *
     * @param QuoteItem $subject
     * @param Closure $proceed
     * @param Product $product
     * @return false|mixed
     * @throws NoSuchEntityException
     */
    public function aroundRepresentProduct(
        QuoteItem $subject,
        Closure  $proceed,
        Product  $product
    ): mixed {
        $productId = $product->getId();
        $productCustomizerFlag = $this->viewModel->getProductCustomizerStatus((int) $productId);
        if ($productCustomizerFlag):
            return false;
        else:
            return $proceed($product);
        endif;
    }
}
