<?php
/**
 * Copyright © LTIMindtree All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace LTIM\ProductImageCustomizer\Block\Adminhtml\Order\View\Tab;

use Magento\Framework\View\Element\Template;
use Magento\Backend\Block\Template\Context;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Phrase;
use Magento\Framework\Registry;
use Magento\Sales\Model\Order;
use LTIM\ProductImageCustomizer\ViewModel\Data;

class ProductImageCustomizerTab extends Template implements TabInterface
{
    /**
     * @var string
     */
    protected $_template = 'LTIM_ProductImageCustomizer::order/view/tab/product_customizer.phtml';

    /**
     * @var Registry
     */
    private $_coreRegistry;

    /**
     * @var Data
     */
    private Data $dataViewModel;

    /**
     * Product Image Customizer Tab constructor
     *
     * @param Context $context
     * @param Registry $registry
     * @param Data $dataViewModel
     * @param array $data
     */
    public function __construct(
        Context  $context,
        Registry $registry,
        Data     $dataViewModel,
        array    $data = []
    ) {
        $this->_coreRegistry = $registry;
        $this->dataViewModel = $dataViewModel;
        parent::__construct($context, $data);
    }

    /**
     * Retrieve current order model instance
     *
     * @return Order
     */
    public function getOrder(): Order
    {
        return $this->_coreRegistry->registry('current_order');
    }

    /**
     * Get Media Directory
     *
     * @return string
     * @throws NoSuchEntityException
     */
    public function getMediaDirectory(): string
    {
        return $this->dataViewModel->getMediaDirectory();
    }

    /**
     * {@inheritdoc}
     */
    public function getTabLabel(): Phrase|string
    {
        return __('Product Image Customizer');
    }

    /**
     * {@inheritdoc}
     */
    public function getTabTitle(): Phrase|string
    {
        return __('Product Image Customizer');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab(): bool
    {
         return ($this->dataViewModel->isModuleEnabled()) == '1';
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden(): bool
    {
        return false;
    }
}