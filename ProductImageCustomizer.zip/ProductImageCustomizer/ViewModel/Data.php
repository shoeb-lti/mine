<?php
/**
 * Copyright © LTIMindtree All rights reserved.
 * See COPYING.txt for license details.
 */

namespace LTIM\ProductImageCustomizer\ViewModel;

use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\Block\ArgumentInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\Registry;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Store\Model\StoreManagerInterface;

class Data implements ArgumentInterface
{
    public const XML_PATH_MODULE_STATUS = "product_customizer/configuration/enable";

    /**
     * @var ScopeConfigInterface
     */
    protected ScopeConfigInterface $_scopeConfig;

    /**
     * @var Registry
     */
    protected Registry $_registry;

    /**
     * @var ProductRepositoryInterface
     */
    protected ProductRepositoryInterface $_productRepository;

    /**
     * @var StoreManagerInterface
     */
    protected StoreManagerInterface $_storeManagerInterface;

    /**
     * @param ScopeConfigInterface $scopeConfig
     * @param Registry $registry
     * @param ProductRepositoryInterface $productRepository
     * @param StoreManagerInterface $storeManagerInterface
     */
    public function __construct(
        ScopeConfigInterface       $scopeConfig,
        Registry                   $registry,
        ProductRepositoryInterface $productRepository,
        StoreManagerInterface      $storeManagerInterface,
    ) {
        $this->_scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->_productRepository = $productRepository;
        $this->_storeManagerInterface = $storeManagerInterface;
    }

    /**
     * Returns the ProductImageCustomizer Module Status
     *
     * @param int|null $productId
     * @return bool
     * @throws NoSuchEntityException
     */
    public function getProductCustomizerStatus(int $productId = null): bool
    {
        $path = self::XML_PATH_MODULE_STATUS;
        $moduleStatus = $this->_scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE);
        if (!$productId):
            $currentProduct = $this->_registry->registry('current_product');
            $productId = $currentProduct->getId();
        endif;
        try {
            $product = $this->_productRepository->getById($productId);
        } catch (NoSuchEntityException $e) {
            throw new NoSuchEntityException(__($e->getMessage()));
        }
        $individualProductCustomizerStatus = $product->getData("is_product_customizer");
        if ($moduleStatus && $individualProductCustomizerStatus):
            return true;
        endif;
        return false;
    }

    /**
     * Get Media Directory Path
     *
     * @return string
     * @throws NoSuchEntityException
     */
    public function getMediaDirectory(): string
    {
        try {
            $mediaPath = $this->_storeManagerInterface->getStore()->getBaseUrl(
                UrlInterface::URL_TYPE_MEDIA
            );
        } catch (NoSuchEntityException $e) {
            throw new NoSuchEntityException(__($e->getMessage()));
        }
        return $mediaPath . 'product_customizer';
    }

    /**
     * Check Module Enabled
     *
     * @return string
     */
    public function isModuleEnabled(): string
    {
        return $this->_scopeConfig->getValue(
            self::XML_PATH_MODULE_STATUS,
            ScopeInterface::SCOPE_STORE
        );
    }
}
