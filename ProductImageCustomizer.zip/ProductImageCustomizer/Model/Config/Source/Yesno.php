<?php
/**
 * Copyright © LTIMindtree All rights reserved.
 * See COPYING.txt for license details.
 */

namespace LTIM\ProductImageCustomizer\Model\Config\Source;

use Magento\Eav\Model\Entity\Attribute\Source\AbstractSource;

class Yesno extends AbstractSource
{
    /**
     * @var Options
     */
    protected $_options;

    /**
     * Get All Options
     *
     * @return array
     */
    public function getAllOptions(): array
    {
        if ($this->_options === null) {
            $this->_options = [
                ['value' => '', 'label' => ''],
                ['value' => 0, 'label' => __('No')],
                ['value' => 1, 'label' => __('Yes')]

            ];
        }
        return $this->_options;
    }

    /**
     * Get Options Array
     *
     * @return array
     */
    public function toOptionArray(): array
    {
        return [
            ['value' => '', 'label' => ''],
            ['value' => 'No', 'label' => __('No')],
            ['value' => 'Yes', 'label' => __('Yes')]
        ];
    }
}
