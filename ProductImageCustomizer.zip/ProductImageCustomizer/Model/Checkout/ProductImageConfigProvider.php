<?php
/**
 * Copyright © LTIMindtree All rights reserved.
 * See COPYING.txt for license details.
 */

namespace LTIM\ProductImageCustomizer\Model\Checkout;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use LTIM\ProductImageCustomizer\ViewModel\Data;

/**
 * Product Image Config Provider For Checkout
 */
class ProductImageConfigProvider implements ConfigProviderInterface
{
    /**
     * @var Data
     */
    protected Data $dataViewModel;

    /**
     * @param Data $dataViewModel
     */
    public function __construct(
        Data $dataViewModel
    ) {
        $this->dataViewModel = $dataViewModel;
    }

    /**
     * Get Config Provider
     *
     * @throws NoSuchEntityException
     */
    public function getConfig(): array
    {
        $config = [];
        $config['getMediaPath'] = $this->dataViewModel->getMediaDirectory();
        return $config;
    }
}
